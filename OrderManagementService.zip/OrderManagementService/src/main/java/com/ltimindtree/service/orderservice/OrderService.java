package com.ltimindtree.service.orderservice;

import java.util.List;
import java.util.Optional;

import com.ltimindtree.dto.OrderRequestDTO;
import com.ltimindtree.entity.Order;
import com.ltimindtree.exception.OrderException;
import com.ltimindtree.exception.ResourceNotFoundException;

public interface OrderService {
	
	
	public List<Order> viewOrder() throws OrderException;
	public Order viewOrderById(long id) throws ResourceNotFoundException;
	public Order createOrders(OrderRequestDTO orderRequest);
	public void deleteOrderById(long id);
	public Order updateOrder(Order order, long id) throws ResourceNotFoundException;
	public double getOrderAmountByOrderId(Order order, long id) throws ResourceNotFoundException;
	public Order placeOrder(Order orderss);
	

}
