package com.ltimindtree.service.orderservice.impl;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ltimindtree.dto.OrderRequestDTO;
import com.ltimindtree.entity.ItemDetails;
import com.ltimindtree.entity.Order;
import com.ltimindtree.exception.OrderException;
import com.ltimindtree.exception.ResourceNotFoundException;
import com.ltimindtree.repository.OrderRepository;
import com.ltimindtree.service.orderservice.OrderService;


@Service
public  class OrderServiceImpl implements OrderService{
	
	@Autowired
	private OrderRepository orderRepository;

	@Override
	public List<Order> viewOrder() throws OrderException {
		// TODO Auto-generated method stub
		return orderRepository.findAll();
	}

	@Override
	public Order viewOrderById(long id) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		return orderRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Order", "Id", id));
	}

	@Override
	public Order createOrders(OrderRequestDTO orderRequest) {
		// TODO Auto-generated method stub
		return orderRepository.save(orderRequest.getOrders());
	}

	@Override
	public void deleteOrderById(long id) {
		// TODO Auto-generated method stub
		orderRepository.deleteById(id);
		
	}

	@Override
	public Order updateOrder(Order order, long id) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Order existingOrder=orderRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Order", "Id", id));
		existingOrder.setRestaurantId(order.getRestaurantId());
		existingOrder.setCustomerId(order.getCustomerId());
		existingOrder.setCreateDateTime(order.getCreateDateTime());
		existingOrder.setUpdateDateTime(order.getUpdateDateTime());
		existingOrder.setItemDetail(order.getItemDetail());
		existingOrder.setStatus(order.getStatus());
		
		return orderRepository.save(existingOrder);
	}

	@Override
	public double getOrderAmountByOrderId(Order order, long id) throws ResourceNotFoundException {
		//List<Order> itemsOrdered= orderRepository.findOrderById(id);
		//if(itemsOrdered !=null) {
		
		Order orders=orderRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Order", "Id", id));
		if(orders != null) {
			
		
		double totalAmount=0;
			for(ItemDetails item: order.getItemDetail() ) {
				double itemTotal=  item.getPrice() * item.getQuantity();
				totalAmount+=itemTotal;
			}
			return totalAmount;
		}
	
	else {
		return 0;
	}
	
	}

	@Override
	public Order placeOrder(Order orderss) {
		// TODO Auto-generated method stub
		if(orderss.getItemDetail()==null || orderss.getItemDetail().isEmpty()) {
			throw new IllegalArgumentException("Order must have at least one item");
		}
		orderss.setCreateDateTime(LocalDateTime.now());
		orderss.setUpdateDateTime(LocalDateTime.now());
		
		for(ItemDetails item : orderss.getItemDetail()) {
			item.setOrders(orderss);
		}
		orderss.setStatus("PLACED");
		return orderRepository.save(orderss);
	}
		
	
}
