package com.ltimindtree.dto;

import com.ltimindtree.entity.Order;

public class OrderRequestDTO {
	
	private Order orders;

	public OrderRequestDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderRequestDTO(Order orders) {
		super();
		this.orders = orders;
	}

	public Order getOrders() {
		return orders;
	}

	public void setOrders(Order orders) {
		this.orders = orders;
	}

	@Override
	public String toString() {
		return "RequestDTO [orders=" + orders + "]";
	}
	
	

}
