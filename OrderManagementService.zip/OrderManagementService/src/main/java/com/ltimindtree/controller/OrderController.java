package com.ltimindtree.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltimindtree.dto.OrderRequestDTO;
import com.ltimindtree.entity.Order;
import com.ltimindtree.exception.OrderException;
import com.ltimindtree.exception.ResourceNotFoundException;
import com.ltimindtree.repository.OrderRepository;
import com.ltimindtree.service.orderservice.OrderService;
import com.ltimindtree.service.orderservice.impl.OrderServiceImpl;


@RestController
@RequestMapping("/orders")
public class OrderController {
	
	@Autowired
	private OrderServiceImpl orderImpl;
	
	
	private Map<String, Object> response;
	
	
	
	//localhost:8080/orders/orderCreatess
	@PostMapping("/orderCreatess")
	public ResponseEntity<Map<String, Object>> placingOrders(@RequestBody OrderRequestDTO ordersRequest){
		response=new HashMap<String,Object>();
		response.put("message", "order created successfully");
		response.put("status", HttpStatus.OK);
		response.put("body", orderImpl.createOrders(ordersRequest));
		response.put("error", false);
		return new ResponseEntity<Map<String, Object>>(response,HttpStatus.OK);
		
		
	}
	
	//localhost:8080/orders/viewallorders
	@GetMapping("/viewallorders")
	public ResponseEntity<Map<String,Object>> viewOrder() throws OrderException {
		response=new HashMap<String,Object>();
		response.put("message", "orders view by id successfully");
		response.put("status", HttpStatus.OK);
		response.put("body", orderImpl.viewOrder());
		response.put("error", false);
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
		
	}

	
	//localhost:8080/orders/1
		@GetMapping("/{id}")
		public ResponseEntity<Map<String,Object>> viewOrderById(@PathVariable int id) throws ResourceNotFoundException{
			response=new HashMap<String,Object>();
			response.put("message", "orders view by id successfully");
			response.put("status", HttpStatus.OK);
			response.put("body", orderImpl.viewOrderById(id));
			response.put("error", false);
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
			
		}
	
	
	//localhost:8080/orders/ordersUpdate/
	@PutMapping("/ordersUpdate/{id}")
	public ResponseEntity<Map<String, Object>> updateOrder(@RequestBody Order order,@PathVariable (value = "id") int id) throws ResourceNotFoundException{
		response=new HashMap<String,Object>();
		response.put("message", "orders updated successfully");
		response.put("status", HttpStatus.OK);
		response.put("body", orderImpl.updateOrder(order, id));
		response.put("error", false);
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
		
	}
	
	//localhost:8080/orders/
		@DeleteMapping("/{id}")
		public ResponseEntity<String> cancelOrder(@PathVariable("id") int id){
			orderImpl.deleteOrderById(id);
			return new ResponseEntity<String>("Order Deleted",HttpStatus.OK);
		}
	
	//localhost:8080/orders/total/
		@GetMapping("/total/{id}")
		public ResponseEntity<Map<String,Object>> calculateTotalAmount(@RequestBody Order orders,@PathVariable long id) throws ResourceNotFoundException{
			response=new HashMap<String,Object>();
			response.put("message", "Total amount based on number of item ordered");
			response.put("status", HttpStatus.OK);
			response.put("Total amount", orderImpl.getOrderAmountByOrderId(orders, id));
			response.put("error", false);
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
		}
		
		//localhost:8080/orders/place
		@PostMapping("/place")
		public ResponseEntity<Order> placeOrder(@RequestBody Order order){
			try {
				Order placedOrder=orderImpl.placeOrder(order);
				return ResponseEntity.ok(placedOrder);
			} catch (IllegalArgumentException ex) {
				// TODO: handle exception
				return ResponseEntity.badRequest().body(null);
			}
		}
	


}
